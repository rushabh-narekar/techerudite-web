import AppRouter from "../src/routes/AppRouter";
import React from "react";
import './assets/styles/global.css'

function App() {
  return (
    <div>
      <AppRouter />
    </div>
  );
}

export default App;
